<?php

/**
 * 
 * Plugin Name: Imonetizeit Redirect Tool
 * Description: This plugin redirects your mobile traffic to a specific website.
 * Version: 1.0
 * Author: Imonetizeit
 * Author URI:  http://www.imonetizeit.com
 * Text Domain: Imonetizeit
 * License: GNU General Public License
 * License URI: license.txt
*/

include(dirname(__FILE__) . '/includes/_imonetizeit_plugin.class.php');
register_activation_hook(__FILE__, array('ImonetizeitRTPlugin', 'install'));
register_deactivation_hook(__FILE__, array('ImonetizeitRTPlugin', 'uninstall'));
add_filter('plugin_action_links', array($MRT,'wp_plugin_links'), 10, 3);
add_action('admin_head', array($MRT, 'wp_admin_head'));
add_action('admin_menu', array($MRT, 'wp_admin_menu'));