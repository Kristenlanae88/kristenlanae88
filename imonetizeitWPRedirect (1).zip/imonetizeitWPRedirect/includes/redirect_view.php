<?php
    $redirect_url = $u_data->url;
?>
<p style="color: #06a2e0;">This plugin redirects your mobile traffic to <?php echo $redirect_url ?></p>
<form method="post">
<div class="mr_table">
	<div class="mr_cell">
		<h2>Step 1</h2>
		<p>Redirect to URL:</p>
        <input type="text" name="url" value="<?php echo $u_data->url ?>"/>
	</div>
	<div class="mr_cell _three">
		<h2>Step 2</h2>
		<p>Optional Targeting</p>
		<input type="checkbox" name="excludeTablets" id="excludeTablets"<?php echo $u_data->excludeTablets ? ' checked="checked"' : '' ?>><label for="excludeTablets">Exclude iPads</label> <br>
		<input type="checkbox" name="excludeIOSAndroid" id="excludeIOSAndroid"<?php echo $u_data->excludeIOSAndroid ? ' checked="checked"' : '' ?>><label for="excludeIOSAndroid">Exclude iOS and Android</label>
		<p class="description">You redirect us only old phones that can't view your website</p>
	</div>
</div>
<p class="sumbit">
<input type="submit" id="mrt_sbmt" name="save" value="<?php echo __('Save settings') ?>" />
</p>
<?php if( count( $_POST ) ): ?>
<p class="notify"><strong>Your changes have been saved.</strong></p>
<p class="notify">Your mobile traffic (<?php
if( $u_data->excludeIOSAndroid ) echo "excluding iOS and Android devices";
elseif( !$u_data->excludeTablets ) echo "including iOS and Android devices";
else echo "excluding iPads";
?>) will be redirected to <?php echo $redirect_url ?></p>
<?php endif; ?>
<script type="text/javascript">
var et	= document.getElementById('excludeTablets');
var ea	= document.getElementById('excludeIOSAndroid');
if (document.addEventListener) {
	  et.addEventListener('change', un_check, false);
	  ea.addEventListener('change', un_check, false);
} else if (document.attachEvent)  {
	  et.attachEvent('onchange', un_check);
	  ea.attachEvent('onchange', un_check);
}
function un_check(e){
	if( this.getAttribute('id') == 'excludeIOSAndroid' && this.checked ){
		et.checked = true;
	} else if( this.getAttribute('id') == 'excludeTablets' && !this.checked ) {
		ea.checked = false;
	}
}
</script>
</form>